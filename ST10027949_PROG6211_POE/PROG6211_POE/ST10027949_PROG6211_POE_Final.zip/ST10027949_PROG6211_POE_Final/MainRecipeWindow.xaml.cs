﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10027949_PROG6211_POE_Final
{

    /// <summary>
    /// Interaction logic for MainRecipeWindow.xaml
    /// </summary>
    public partial class MainRecipeWindow : Window
    {
        public MainRecipeWindow()
        {
            InitializeComponent();
        }

        private void Create(object sender, RoutedEventArgs e)
        {
            RecipeDetails RecipeDetails = new RecipeDetails();
            RecipeDetails.Show();
        }

        private void Read(object sender, RoutedEventArgs e)
        {
            ViewRecipes viewrec = new ViewRecipes();
            viewrec.Show();
        }

        private void Quit(object sender, RoutedEventArgs e)
        {
            Close();
        }

    }
}
