﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10027949_PROG6211_POE_Final
{

    /// <summary>
    /// Interaction logic for RecipeDetails.xaml
    /// </summary>
    /// 

    public partial class RecipeDetails : Window
    {
        // Declare generic collections to store ingredient details
        List<string> IngredientNames = new List<string>();
        List<double> IngredientQuantities = new List<double>();
        List<string> MeasurementUnits = new List<string>();
        List<double> IngredientCalories = new List<double>();
        List<string> IngredientFoodGroups = new List<string>();

        public RecipeDetails()
        {
            InitializeComponent();
        }

        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear any existing ingredient fields
            FormStackPanel.Children.Clear();

            // Add input fields for recipe name and number of ingredients
            FormStackPanel.Children.Add(new Label() { Content = "Recipe Name:" });
            FormStackPanel.Children.Add(RecipeNameTextBox);
            FormStackPanel.Children.Add(new Label() { Content = "Number of Ingredients:" });
            FormStackPanel.Children.Add(NumberOfIngredientsTextBox);
            FormStackPanel.Children.Add(sender as Button);

            // Get the number of ingredients
            int numberOfIngredients = int.Parse(NumberOfIngredientsTextBox.Text);

            // Generate input fields for each ingredient
            for (int i = 0; i < numberOfIngredients; i++)
            {
                FormStackPanel.Children.Add(new Label() { Content = $"Ingredient {i + 1} Name:" });
                FormStackPanel.Children.Add(new TextBox());
                FormStackPanel.Children.Add(new Label() { Content = "Quantity:" });
                FormStackPanel.Children.Add(new TextBox());
                FormStackPanel.Children.Add(new Label() { Content = "Unit:" });
                FormStackPanel.Children.Add(new TextBox());
                FormStackPanel.Children.Add(new Label() { Content = "Calories:" });
                FormStackPanel.Children.Add(new TextBox());
                FormStackPanel.Children.Add(new Label() { Content = "Food Group:" });

                // Create a ComboBox for the food group
                ComboBox foodGroupComboBox = new ComboBox();
                foodGroupComboBox.Items.Add("Vegetables");
                foodGroupComboBox.Items.Add("Fruits");
                foodGroupComboBox.Items.Add("Grains");
                foodGroupComboBox.Items.Add("Protein Foods");
                foodGroupComboBox.Items.Add("Dairy");
                foodGroupComboBox.Items.Add("Oils & Solid Fats");
                foodGroupComboBox.Items.Add("Added Sugars");
                foodGroupComboBox.Items.Add("Beverages");

                // Add the ComboBox to the FormStackPanel
                FormStackPanel.Children.Add(foodGroupComboBox);
            }

            // Add the Save button
            Button saveButton = new Button() { Content = "Save" };
            saveButton.Click += SaveButton_Click;
            FormStackPanel.Children.Add(saveButton);
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a new ArrayList to store the recipe details
            ArrayList recipeDetails = new ArrayList();

            // Add the recipe name to the ArrayList
            recipeDetails.Add(RecipeNameTextBox.Text);

            // Get the number of ingredients
            int numberOfIngredients = int.Parse(NumberOfIngredientsTextBox.Text);

            // Loop through each ingredient and add its details to the ArrayList
            for (int i = 0; i < numberOfIngredients; i++)
            {
                // Get the input fields for the current ingredient
                TextBox ingredientNameTextBox = FormStackPanel.Children.OfType<TextBox>().ElementAt(i * 5);
                TextBox ingredientQuantityTextBox = FormStackPanel.Children.OfType<TextBox>().ElementAt(i * 5 + 1);
                TextBox ingredientUnitTextBox = FormStackPanel.Children.OfType<TextBox>().ElementAt(i * 5 + 2);
                TextBox ingredientCaloriesTextBox = FormStackPanel.Children.OfType<TextBox>().ElementAt(i * 5 + 3);
                TextBox ingredientFoodGroupTextBox = FormStackPanel.Children.OfType<TextBox>().ElementAt(i * 5 + 4);

                // Add the ingredient details to the ArrayList
                recipeDetails.Add(ingredientNameTextBox.Text);
                recipeDetails.Add(double.Parse(ingredientQuantityTextBox.Text));
                recipeDetails.Add(ingredientUnitTextBox.Text);
                recipeDetails.Add(double.Parse(ingredientCaloriesTextBox.Text));
                recipeDetails.Add(ingredientFoodGroupTextBox.Text);
            }

            MainRecipeWindow MainRecipeWindow = new MainRecipeWindow();
            MainRecipeWindow.Show();
        }

    }
}


