﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10027949_PROG6211_POE_Final
{
    public partial class ViewRecipes : Window
    {
        public class Ingredient
        {
            public string Name { get; set; }
            public double Quantity { get; set; }
            public string Unit { get; set; }
            public double Calories { get; set; }
            public string FoodGroup { get; set; }
        }
        public ViewRecipes(ArrayList recipeDetails)
        {
            InitializeComponent();

            // Set the recipe name
            RecipeNameTextBlock.Text = recipeDetails[0] as string;

            // Create a list to store the ingredients
            List<Ingredient> ingredients = new List<Ingredient>();

            // Get the number of ingredients
            int numberOfIngredients = (recipeDetails.Count - 1) / 5;

            // Loop through each ingredient and add it to the list
            for (int i = 0; i < numberOfIngredients; i++)
            {
                // Create a new Ingredient object
                Ingredient ingredient = new Ingredient()
                {
                    Name = recipeDetails[i * 5 + 1] as string,
                    Quantity = (double)recipeDetails[i * 5 + 2],
                    Unit = recipeDetails[i * 5 + 3] as string,
                    Calories = (double)recipeDetails[i * 5 + 4],
                    FoodGroup = recipeDetails[i * 5 + 5] as string
                };

                // Add the ingredient to the list
                ingredients.Add(ingredient);
            }

            // Set the ItemsSource of the IngredientsItemsControl to the list of ingredients
            IngredientsItemsControl.ItemsSource = ingredients;
        }

        public ViewRecipes()
        {
        }
    }

}
